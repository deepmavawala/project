﻿using ContactsAPI.Data;
using ContactsAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ContactsAPI.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class ContactsController : Controller
	{
		private readonly ContactsAPIDbContext _dbContext;
		public ContactsController(ContactsAPIDbContext dbContext)
		{
			_dbContext = dbContext;
		}
		[HttpGet]
		public IActionResult GetAllContacts()
		{
			return Ok(_dbContext.Contacts.ToList());
		}
		[HttpGet]
		[Route("{id:guid}")]
		public IActionResult GetContactById([FromRoute] Guid id) 
		{
			var contact = _dbContext.Contacts.Find(id);
			if (contact == null) 
			{
				return NotFound();
			}
			return Ok(contact);
		}
		[HttpPost]
		public IActionResult AddContactList(AddContactRequest contactRequest)
		{
			var contact = new Contact()
			{
				Id = new Guid(),
				Address = contactRequest.Address,
				Email = contactRequest.Email,
				FullName = contactRequest.FullName,
				Phone = contactRequest.Phone,
			};
			_dbContext.Contacts.Add(contact);
			_dbContext.SaveChanges();
			return Ok(contactRequest);
		}
		[HttpPut]
		[Route("{id:guid}")]
		public IActionResult UpdateContact([FromRoute] Guid id,UpdateContactRequest updateContact)
		{
			var contact = _dbContext.Contacts.Find(id);
			if (contact != null) 
			{
				contact.Email = updateContact.Email;
				contact.FullName = updateContact.FullName;
				contact.Phone = updateContact.Phone;
				contact.Address = updateContact.Address;
				_dbContext.SaveChanges();
				return Ok(contact);
			}
			return NotFound();
		}
		[HttpDelete]
		[Route("{id:guid}")]
		public IActionResult DeleteContact([FromRoute] Guid id) 
		{
			var contact = _dbContext.Contacts.Find(id);
			if (contact != null) 
			{
				_dbContext.Contacts.Remove(contact);
				_dbContext.SaveChanges();
				return Ok(contact);
			}
			return NotFound();
		}
	}
}
