﻿namespace WebAPI2
{
	public class Startup
	{
		public void ConfigureServices(IServiceCollection services)//configureservices method is used to configure all the services for application
		{
			services.AddControllers();
			services.AddTransient<CustomMiddleware>();
		}
		public void configure(IApplicationBuilder app,IWebHostEnvironment env) //Configure method is used process HTTTP Request pipeline
		{
			//app.Use(async (context, next) =>
			//{
			//	await context.Response.WriteAsync("Hello from use1-1\n");
			//	await next();
			//	await context.Response.WriteAsync("Hello from use1-2\n");
			//});
			//app.UseMiddleware<CustomMiddleware>();
			//app.Map("/deep", Customcode);
			//app.Use(async (context, next) =>
			//{
			//	await context.Response.WriteAsync("Hello from use2-1\n");
			//	await next();
			//	await context.Response.WriteAsync("Hello from use2-2\n");
			//});
			//app.Run(async context =>
			//{
			//	await context.Response.WriteAsync("Hello from run1\n");
			//});
			if (env.IsDevelopment()) 
			{
				app.UseDeveloperExceptionPage();
			}
			app.UseRouting();
			app.UseEndpoints(endpoints =>
			{
				endpoints.MapControllers();
				//endpoints.MapGet("/", async context =>
				//{
				//	await context.Response.WriteAsync("Hello from New Web API app");
				//});
				//endpoints.MapGet("/test", async context =>
				//{
				//	await context.Response.WriteAsync("Hello from New Web API app test");
				//});
			});
		}

		private void Customcode(IApplicationBuilder app)
		{
			app.Use(async (context, next) => 
			{
				await context.Response.WriteAsync("Hello Deep");
				await next();
			});
			app.Run(async context =>
			{
				await context.Response.WriteAsync("Hello from run2\n");
			});
		}
	}
}
