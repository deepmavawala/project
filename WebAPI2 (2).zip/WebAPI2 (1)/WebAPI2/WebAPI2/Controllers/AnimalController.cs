﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPI2.Models;

namespace WebAPI2.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class AnimalController : ControllerBase
	{
		public IActionResult GetAnimal() 
		{
			var animals = new List<Animal>()
			{
				new Animal() {Id=1,Name="Dog"}
			};

			return Ok(animals);
		}
	}
}
