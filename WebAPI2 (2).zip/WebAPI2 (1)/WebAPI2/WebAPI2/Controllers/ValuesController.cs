﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlTypes;
using System.Runtime.InteropServices;

namespace WebAPI2.Controllers
{
	[ApiController]
	public class ValuesController : ControllerBase
	{
		[Route("[controller]/[action]")]
		public string GetAll() 
		{
			return "This is method of GetAll";
		}
		[Route("getauthors")]
		public string GetAuthors() 
		{
			return "This is method of Get";
		}
		[Route("getid/{id}")]
		public string GetId(int id)
		{
			return "id = " + id;
		}
		[Route("id/{id}/name/{name}")]
		public string GetIdAndName(int id,string name)
		{
			return "id = " + id+" name= "+name;
		}
		[Route("search")]
		public string searchName(int? id,string name, string? city)
		{
			return "hiii from search";
		}
	}
}
