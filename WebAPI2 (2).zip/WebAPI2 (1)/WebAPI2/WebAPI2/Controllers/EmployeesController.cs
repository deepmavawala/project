﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPI2.Models;

namespace WebAPI2.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class EmployeesController : ControllerBase
	{
		[Route("")]
		public List<EmployeeModel> GetEmployees()
		{
			return new List<EmployeeModel>() { new EmployeeModel{ Id = 1, Name = "Deep Mavawala" } };
		}
		[Route("{id}")]
		public IActionResult GetEmployees(int id)
		{
			if (id == 0)
			{
				return NotFound();
			}
			return Ok(new List<EmployeeModel>()
			{
				new EmployeeModel { Id = 1, Name = "Deep Mavawala" },
				new EmployeeModel { Id = 2, Name = "Dhruv Shah" }
			}
			);
		}
		[Route("{id}/basic")]
		public ActionResult<EmployeeModel> GetEmployeeBasicDetails(int id)
		{
			if(id == 0) 
			{
				return NotFound();
			}
			return new EmployeeModel() { Id = 1, Name = "Employee1" };
		}
	}
}
