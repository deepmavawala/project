﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI2.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class Names : ControllerBase
	{
		[Route("{id:int}")]
		public string GetById(int id)
		{
			return "Hello id "+id;
		}
		[Route("{id}")]
		public string GetByIdString(string id) 
		{
			return "Hello name " + id;
		}
	}
}
