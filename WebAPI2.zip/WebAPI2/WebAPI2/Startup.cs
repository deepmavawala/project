﻿namespace WebAPI2
{
	public class Startup
	{
		public void AddConfigureServices(IServiceCollection services)
		{

		}
		public void configure(IApplicationBuilder app,IWebHostEnvironment env) 
		{
			app.UseRouting();
			app.UseEndpoints(endpoints =>
			{
				endpoints.MapGet("/", async context =>
				{
					await context.Response.WriteAsync("Hello from New Web API app");
				});
			});
		}
	}
}
