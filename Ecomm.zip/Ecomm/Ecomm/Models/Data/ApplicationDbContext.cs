﻿using Microsoft.EntityFrameworkCore;

namespace Ecomm.Models.Data
{
	public class ApplicationDbContext : DbContext
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
		{
		}
		public DbSet<Book> Books { get; set; }
		public DbSet<BookCover> BookCovers { get; set; }
		public DbSet<BookWritter> BookWriters { get; set; }
		//protected override void OnModelCreating(ModelBuilder modelBuilder)
		//{
		//	modelBuilder.Entity<Book>().HasData(
		//		new Book() 
		//		{
		//			BookId = 1,
		//		});
		//}
	}
}
