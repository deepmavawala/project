﻿using Azure.Storage.Blobs;
using Ecomm.Models;

namespace Ecomm.Helper
{
	public static class FileHelper
	{
		public static async Task<string>UploadImage(IFormFile file)
		{
			string filename = Guid.NewGuid().ToString();
			string connectionString = @"DefaultEndpointsProtocol=https;AccountName=deepfunctionstorage;AccountKey=30oGTK2l9LpkjH+85Tc/JKdN5gdPsjbXMqR6JqH+fUcGuseux9TGH8orm/sqzdGimNIdILqRr9Sp+AStzNRYcA==;EndpointSuffix=core.windows.net";
			string containerName = "bookphotos";
			BlobContainerClient containerClient = new BlobContainerClient(connectionString, containerName);
			BlobClient client = containerClient.GetBlobClient(filename+file.FileName);
			MemoryStream ms = new MemoryStream();
			await file.CopyToAsync(ms);
			ms.Position = 0;
			client.UploadAsync(ms);
			return client.Uri.ToString();
		}
		public static async Task<string> UploadUrl(IFormFile file)
		{
			string filename = Guid.NewGuid().ToString();
			string connectionString = @"DefaultEndpointsProtocol=https;AccountName=deepfunctionstorage;AccountKey=30oGTK2l9LpkjH+85Tc/JKdN5gdPsjbXMqR6JqH+fUcGuseux9TGH8orm/sqzdGimNIdILqRr9Sp+AStzNRYcA==;EndpointSuffix=core.windows.net";
			string containerName = "bookurl";
			BlobContainerClient containerClient = new BlobContainerClient(connectionString, containerName);
			BlobClient client = containerClient.GetBlobClient(filename+file.FileName);
			MemoryStream ms = new MemoryStream();
			await file.CopyToAsync(ms);
			ms.Position = 0;
			client.UploadAsync(ms);
			return client.Uri.ToString();
		}
	}
}
