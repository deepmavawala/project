﻿using Ecomm.Helper;
using Ecomm.Models;
using Ecomm.Models.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Ecomm.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class BooksController : ControllerBase
	{
		private readonly ApplicationDbContext _dbContext;
		public BooksController(ApplicationDbContext dbContext)
		{
			_dbContext = dbContext;
		}
		[HttpPost]
		public async Task<IActionResult> Post([FromForm] Book books)
		{

			books.ImageUrl = await FileHelper.UploadImage(books.ImageFile);
			books.BookUrl = await FileHelper.UploadUrl(books.BookFile);
			await _dbContext.Books.AddAsync(books);
			await _dbContext.SaveChangesAsync();
			return StatusCode(StatusCodes.Status200OK);
		}
	}
}
