﻿using Ecomm.Helper;
using Ecomm.Models;
using Ecomm.Models.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Ecomm.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class CoversController : ControllerBase
	{
		private readonly ApplicationDbContext _dbContext;
		public CoversController(ApplicationDbContext dbContext)
		{
			_dbContext = dbContext;
		}
		[HttpPost]
		public async Task<IActionResult> Post([FromForm] BookCover bookCover)
		{

			bookCover.ImageUrl = await FileHelper.UploadImage(bookCover.ImageFile);
			await _dbContext.BookCovers.AddAsync(bookCover);
			await _dbContext.SaveChangesAsync();
			return StatusCode(StatusCodes.Status200OK);
		}
		[HttpGet]
		public async Task<IActionResult> GetCovers()
		{
			var covers = await (from cover in _dbContext.BookCovers
								 select new
								 {
									 Id = cover.BookCoverId,
									 Name = cover.Title,
									 ImageUrl = cover.ImageUrl,
									 WritterId = cover.BookWritterId
								 }).ToListAsync();
			return Ok(covers);
		}
		[HttpGet("[action]")]
		public async Task<IActionResult> CoverDetails(int id)
		{
			var cover = await (_dbContext.BookCovers.Include(x => x.Book).Where(x => x.BookCoverId == id).FirstOrDefaultAsync());
			return Ok(cover);
		}
	}
}
