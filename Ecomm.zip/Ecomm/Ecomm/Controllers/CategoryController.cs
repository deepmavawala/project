﻿using Azure.Storage.Blobs;
using Ecomm.Models;
using Ecomm.Models.Data;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Ecomm.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class CategoryController : ControllerBase
	{
		private readonly ApplicationDbContext _context;
        public CategoryController(ApplicationDbContext context)
        {
            _context = context;
        }
        // GET: api/<CategoryController>
  //      [HttpGet]
		//public IEnumerable<string> Get()
		//{
		//	return new string[] { "value1", "value2" };
		//}

		// GET api/<CategoryController>/5
		//[HttpGet("{id}")]
		//public string Get(int id)
		//{
		//	return "value";
		//}

		// POST api/<CategoryController>
		//[HttpPost]
		//public async Task<IActionResult> Post([FromForm] Book book)
		//{
		//	string connectionString = @"DefaultEndpointsProtocol=https;AccountName=deepfunctionstorage;AccountKey=30oGTK2l9LpkjH+85Tc/JKdN5gdPsjbXMqR6JqH+fUcGuseux9TGH8orm/sqzdGimNIdILqRr9Sp+AStzNRYcA==;EndpointSuffix=core.windows.net";
		//	string containerName = "deepcontent";
		//	BlobContainerClient containerClient  = new BlobContainerClient(connectionString, containerName);
		//	BlobClient client = containerClient.GetBlobClient(book.ImageFile.FileName);
		//	MemoryStream ms = new MemoryStream();
		//	await book.BookFile.CopyToAsync(ms);
		//	ms.Position = 0;
		//	client.UploadAsync(ms);
		//	book.ImageUrl = client.Uri.ToString();
		//	await _context.Books.AddAsync(book);
		//	await _context.SaveChangesAsync();
		//	return StatusCode(StatusCodes.Status200OK);
		//}

		// PUT api/<CategoryController>/5
		//[HttpPut("{id}")]
		//public void Put(int id, [FromBody] string value)
		//{
		//}

		// DELETE api/<CategoryController>/5
		//[HttpDelete("{id}")]
		//public void Delete(int id)
		//{
		//}
	}
}
