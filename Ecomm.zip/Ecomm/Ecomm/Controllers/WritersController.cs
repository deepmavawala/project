﻿using Ecomm.Helper;
using Ecomm.Models;
using Ecomm.Models.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Ecomm.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class WritersController : ControllerBase
	{
		private readonly ApplicationDbContext _dbContext;
        public WritersController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
		[HttpPost]
		public async Task<IActionResult> Post([FromForm] BookWritter bookWritter)
		{

			bookWritter.ImageUrl = await FileHelper.UploadImage(bookWritter.ImageFile);
			await _dbContext.BookWriters.AddAsync(bookWritter);
			await _dbContext.SaveChangesAsync();
			return StatusCode(StatusCodes.Status200OK);
		}
		[HttpGet]
		public async Task<IActionResult> GetWriters()
		{
			var writers = await (from writer in _dbContext.BookWriters
								 select new
								 {
									 Id = writer.BookWritterId,
									 Name = writer.Name,
									 ImageUrl = writer.ImageUrl,
								 }).ToListAsync();
			return Ok(writers);
		}
		[HttpGet("[action]")]
		public async Task<IActionResult> WritterDetails(int id)
		{
			var writer = await (_dbContext.BookWriters.Include(x => x.Books).Where(x => x.BookWritterId == id).FirstOrDefaultAsync());
			return Ok(writer);
		}
	}
}
