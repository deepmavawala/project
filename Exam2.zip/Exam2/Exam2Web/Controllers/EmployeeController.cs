﻿using Exam2Web.Data;
using Exam2Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Exam2Web.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _db;
        public EmployeeController(ApplicationDbContext db)
        {
            _db = db;
            _db.employees.Include(u => u.Roles);
        }

        public IActionResult Index()
        {
            return View();
        }

        //Get Upsert
        public IActionResult Upsert(int? id)
        {
            Employee employee = new();
            IEnumerable<SelectListItem> RolesList = _db.roles.ToList().Select(
                u => new SelectListItem
                {
                    Text = u.Name,
                    Value = u.Id.ToString(),
                }
            );
            if (id == null || id == 0)
            {
                //Create Employee
                ViewBag.RolesList = RolesList;
                return View(employee);
            }
            else
            {
                var Edata =  _db.employees.Find(id);
                ViewBag.RolesList = RolesList;
                return View(Edata);
                //Update Employee
            }
            
        }

        //Post Upsert
        [HttpPost]
        public IActionResult Upsert(Employee obj)
        {
            if (ModelState.IsValid)
            {
                if(obj.Id == 0)
                {
                    _db.employees.Add(obj);
                }
                else
                {
                    _db.employees.Update(obj);
                }              
                _db.SaveChanges();
                return RedirectToAction("Index");               
            }
            return View(obj);
        }

        //Get Delete
        public IActionResult Delete(int? id)
        {
            Employee employee = new();
            IEnumerable<SelectListItem> RolesList = _db.roles.ToList().Select(
                u => new SelectListItem
                {
                    Text = u.Name,
                    Value = u.Id.ToString(),
                });

                var Employeedelete = _db.employees.Find(id);              
                ViewBag.RolesList = RolesList;
                return View(Employeedelete);          
        }

        //Post Delete
        [HttpPost, ActionName("Delete")]
        public IActionResult DeletePOST(int? id)
        {
            var obj = _db.employees.Find(id);
            if (obj == null)
            {
                return NotFound();
            }

            _db.employees.Remove(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");

        }




        #region API CALLS

        [HttpGet]
        public IActionResult GetAll()
        {
            var employeeList = _db.employees.Include(u => u.Roles).ToList();
            return Json(new {data = employeeList});
        }

        #endregion


    }
}
