﻿using Microsoft.EntityFrameworkCore;
using Practical4.Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practical4.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
        public DbSet<Address> Address { get; set; }
        public DbSet<OrderAddress> orders { get; set; }
    }
}
