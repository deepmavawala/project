﻿using Practical4.Data;
using Practical4.DataAccess.Repository.IRepository;
using Practical4.Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practical4.DataAccess.Repository
{
    public class ShippingOrder : IShippingOrder
    {
        private readonly ApplicationDbContext _db;
        public ShippingOrder(ApplicationDbContext db)
        {
            _db = db;
        }

        public void AddOrder(Address address)
        {
            _db.Add(address);
        }

        public IEnumerable<OrderAddress> GetOrders()
        {
            return _db.orders.ToList();
        }

        public void save()
        {
            _db.SaveChanges();
        }
    }
}
