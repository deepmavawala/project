﻿using Practical4.Data;
using Practical4.DataAccess.Repository.IRepository;
using Practical4.Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practical4.DataAccess.Repository
{
    public class AddressRepository : IAddressRepository
    {
        private readonly ApplicationDbContext _db;
        public AddressRepository(ApplicationDbContext db)
        {
            _db = db;
        }

        public IEnumerable<Address> GetAll()
        {
            return _db.Address.ToList();
        }
    }
}
