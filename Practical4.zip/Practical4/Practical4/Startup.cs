﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Practical4.Data;
using Practical4.DataAccess.Repository;
using Practical4.DataAccess.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
[assembly:FunctionsStartup(typeof(Practical4.Startup))]
namespace Practical4
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            string connection = Environment.GetEnvironmentVariable("DefaultConnection");
            builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseMySql(
                connection, ServerVersion.AutoDetect(connection)));
            builder.Services.AddScoped<IShippingOrder, ShippingOrder>();
            builder.Services.AddScoped<IAddressRepository, AddressRepository>();
        }
    }
}
