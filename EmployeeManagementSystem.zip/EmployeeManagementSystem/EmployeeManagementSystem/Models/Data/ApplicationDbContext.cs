﻿using Microsoft.EntityFrameworkCore;

namespace EmployeeManagementSystem.Models.Data
{
	public class ApplicationDbContext : DbContext
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
		{
		}
		public DbSet<EmployeeDetails> EmployeeDetails { get; set; }
		public DbSet<Roles> Roles { get; set; }
	}
}
